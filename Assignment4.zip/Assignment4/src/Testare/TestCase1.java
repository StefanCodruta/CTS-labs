package Testare;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import Exceptii.ExceptieIndex;
import Exceptii.ExceptieNume;
import Exceptii.ExceptiePret;
import Exceptii.ExceptieProduseNevanduteSapt;
import Exceptii.ExceptieProduseVandute;
import Model.InterfataProdus;
import Model.Produs;
import Model.TesteImportante;

public class TestCase1 {

	static Produs produs;
	static String numeInitial;
	static float pretInitial;
	static int nrProduseVandute;
	static ArrayList<Integer> produseVandute = new ArrayList<>();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		numeInitial = "soia"; // 4 caractere
		pretInitial = InterfataProdus.MIN_PRET + 1.0f;

		for (int i = 0; i < nrProduseVandute; i++) {
			produseVandute.add(InterfataProdus.MIN_PRODUSE_VANDUTE + 1);
		}

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		produseVandute.clear();
		produseVandute = null;

	}

	@Before
	public void setUp() throws Exception {
		produs = new Produs("cartofi", pretInitial, produseVandute);
	}

	@After
	public void tearDown() throws Exception {
		produs = null;
	}

	@Test
	public void testConstructorFaraProduseVanduteRight() throws ExceptieNume, ExceptiePret {

		Produs produsNou = new Produs(numeInitial, pretInitial);

		assertEquals("numele nu este initializat corect", numeInitial, produs.getName());
		assertEquals("pretul nu este initialzat corect ", pretInitial, produs.getPret(), 0.0f);
	}

	@Test(expected = ExceptieNume.class)
	public void testConstructorFaraProduseErrorConditionNume() throws ExceptieNume, ExceptiePret {

		String numeProdusNou = "ou";
		Produs produs = new Produs(numeProdusNou, pretInitial);
	}

	@Test(expected = ExceptiePret.class)
	public void testConstructorFaraProduseErrorConditionPret() throws ExceptieNume, ExceptiePret {
		float pretNou = InterfataProdus.MIN_PRET - 1;
		Produs produs = new Produs(numeInitial, pretNou);
	}

	@Test
	public void testConstructorCuProduseVanduteRight()
			throws ExceptiePret, ExceptieNume, ExceptieProduseNevanduteSapt, ExceptieIndex {
		Produs produs = new Produs(numeInitial, pretInitial, produseVandute);

		assertEquals("nume incorect", numeInitial, produs.getName());
		assertEquals("pret incorect", pretInitial, produs.getPret(), 0.0f);
		for (int i = 0; i < nrProduseVandute; i++) {
			assertEquals("nr de produse nu este initializat corespunzator", nrProduseVandute,
					produs.getNrProduseVandute(i));
		}

	}

	@Test(expected = ExceptieNume.class)
	public void testConstructorCuProduseErrorConditionNume()
			throws ExceptieNume, ExceptiePret, ExceptieProduseNevanduteSapt {

		String numeProdusNou = "ou";
		Produs produs = new Produs(numeProdusNou, pretInitial, produseVandute);
	}

	@Test(expected = ExceptiePret.class)
	public void testConstructorCuProduseErrorConditionPret()
			throws ExceptiePret, ExceptieNume, ExceptieProduseNevanduteSapt {
		float pretNou = InterfataProdus.MIN_PRET - 1;
		Produs produs = new Produs(numeInitial, pretNou, produseVandute);
	}

	@Category(TesteImportante.class)
	@Test(expected = ExceptieProduseNevanduteSapt.class)
	public void testExistanceConstructorCuProduseVandute()
			throws ExceptiePret, ExceptieNume, ExceptieProduseNevanduteSapt {

		ArrayList<Integer> nrProduseVanduteSapt = null;
		produs = new Produs(numeInitial, pretInitial, nrProduseVanduteSapt);
	}

	@Test
	public void testSetVanzariReference() throws ExceptieProduseNevanduteSapt, ExceptieIndex {

		ArrayList<Integer> nrProduseVanduteSaptamanal = new ArrayList<>();
		int prodVandut1 = InterfataProdus.MIN_PRODUSE_VANDUTE + 1;
		int prodVandut2 = InterfataProdus.MIN_PRODUSE_VANDUTE + 2;
		nrProduseVanduteSaptamanal.add(prodVandut1);
		nrProduseVanduteSaptamanal.add(prodVandut2);

		produs.setVanzari(nrProduseVanduteSaptamanal);

		ArrayList<Integer> nr = new ArrayList<>();
		for (int i = 0; i < produs.getNrSaptamani(); i++) {
			nr.add(produs.getNrProduseVandute(i));

		}

		nrProduseVanduteSaptamanal.set(0, prodVandut1 + 1);
		nrProduseVanduteSaptamanal.set(0, prodVandut1 + 2);

		ArrayList<Integer> nrProduseVanduteNou = new ArrayList<>();
		for (int i = 0; i < produs.getNrSaptamani(); i++) {
			nrProduseVanduteNou.add(produs.getNrProduseVandute(i));
		}

		assertArrayEquals(nr.toArray(), nrProduseVanduteNou.toArray());
	}

	@Test(expected = ExceptieProduseNevanduteSapt.class)
	public void testSetVanzariExistence() throws ExceptieProduseNevanduteSapt {
		ArrayList<Integer> produseVanduteSapt = null;
		produs.setVanzari(produseVanduteSapt);

	}

}
