package Testare;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import Model.TesteImportante;

@RunWith(Categories.class)
@SuiteClasses({ TestCase1.class, TestCase2.class, TestCase3.class, TestSuite.class })
@Categories.IncludeCategory({TesteImportante.class})
public class TestSuiteImportant {

}
