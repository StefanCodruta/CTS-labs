package Testare;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import Exceptii.ExceptieIndex;
import Exceptii.ExceptieLimita;
import Exceptii.ExceptieLimitaMinimaNegativa;
import Exceptii.ExceptieProduseNevanduteSapt;
import Model.InterfataProdus;
import Model.Produs;
import Model.TesteImportante;

public class TestCase3 {

	static Produs produs;
	static String numeInitial;
	static float pretInitial;
	static int nrProduseVandute;
	static ArrayList<Integer> produseVandute = new ArrayList<>();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		numeInitial = "lapte";
		pretInitial = InterfataProdus.MIN_PRET + 1.0f;
		for (int i = 0; i < nrProduseVandute; i++) {
			produseVandute.add(InterfataProdus.MIN_PRODUSE_VANDUTE + 1);
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		produseVandute.clear();
		produseVandute = null;
	}

	@Before
	public void setUp() throws Exception {
		produs = new Produs(numeInitial, pretInitial, produseVandute);
	}

	@After
	public void tearDown() throws Exception {
		produs = null;
	}

	@Category(TesteImportante.class)
	@Test
	public void testGetProcentSaptSlabeRight() throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa, ExceptieLimita{
		ArrayList<Integer> produseVandute= new ArrayList<>(Arrays.asList(
				InterfataProdus.MIN_PRODUSE_VANDUTE +1, InterfataProdus.MIN_PRODUSE_VANDUTE));
		produs.setVanzari(produseVandute);
		int limita=InterfataProdus.MIN_PRODUSE_VANDUTE+1;
		int procentDeObtinut=50;
		int procent = produs.getProcentSaptamaniSlabe(limita);
		assertEquals(procent,procentDeObtinut);
	}
	
	@Test
	public void testGetIndexSaptCuVanzMaximeCrossCheck() throws ExceptieProduseNevanduteSapt, ExceptieLimita, ExceptieIndex{
		ArrayList<Integer> produseVandute= new ArrayList<>(Arrays.asList(
				InterfataProdus.MIN_PRODUSE_VANDUTE +1, InterfataProdus.MIN_PRODUSE_VANDUTE));
		produs.setVanzari(produseVandute);
		
		ArrayList<Integer> indexAsteptat= new ArrayList<>();
		for(int i=0; i< produs.getNrSaptamani();i++) {
			if(Collections.max(produs.getProduseVanduteSapt())<= produs.getNrProduseVandute(i)) {
				indexAsteptat.add(i);
			}
		}
		ArrayList<Integer> indexSapt = produs.getIndexSaptamaniCuVanzariMaxime();
		assertEquals(indexAsteptat,indexSapt);
	}
	
	@Test
	public void testGetIndexSaptCuVanzMaximeRight() throws ExceptieProduseNevanduteSapt, ExceptieLimita, ExceptieIndex{
		ArrayList<Integer> index=new ArrayList<>();
		for(int i=0; i<InterfataProdus.NR_SAPT;i++) {
			index.add(i);
		}
		ArrayList<Integer> indexCalculat= produs.getIndexSaptamaniCuVanzariMaxime();
		
		assertEquals(index, indexCalculat);
	}
	
	@Category(TesteImportante.class)
	@Test
	public void testGetProcentSaptSlabeInverse() throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa, ExceptieLimita{
		ArrayList<Integer> produseVandute= new ArrayList<>(Arrays.asList(
				InterfataProdus.MIN_PRODUSE_VANDUTE +1, InterfataProdus.MIN_PRODUSE_VANDUTE));
		produs.setVanzari(produseVandute);
		
		int limita=InterfataProdus.MIN_PRODUSE_VANDUTE+1;
		int nrSapt =0;
		for(Integer produseVandute1 : produs.getProduseVanduteSapt()) {
			if(produseVandute1 >= limita) {
				nrSapt ++;
			}
		}
		int procentNrSapt = (int)(100* nrSapt/produs.getProduseVanduteSapt().size());
		int procentDorit = 100- procentNrSapt;
		int procentSaptProaste = produs.getProcentSaptamaniSlabe(limita);
		
		assertEquals(procentDorit, procentSaptProaste);
	}

}
