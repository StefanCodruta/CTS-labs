package Testare;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import Exceptii.ExceptieIndex;
import Exceptii.ExceptieLimitaMinimaNegativa;
import Exceptii.ExceptieProduseNevanduteSapt;
import Exceptii.ExceptieProduseVandute;
import Model.InterfataProdus;
import Model.Produs;
import Model.TesteImportante;

public class TestCase2 {

	static Produs produs;
	static String numeInitial;
	static float pretInitial;
	static int nrProduseVandute;
	static ArrayList<Integer> produseVandute = new ArrayList<>();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		numeInitial = "lapte";
		pretInitial = InterfataProdus.MIN_PRET + 1.0f;
		for (int i = 0; i < nrProduseVandute; i++) {
			produseVandute.add(InterfataProdus.MIN_PRODUSE_VANDUTE + 1);
		}

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		produseVandute.clear();
		produseVandute = null;
	}

	@Before
	public void setUp() throws Exception {
		produs = new Produs(numeInitial, pretInitial, produseVandute);
	}

	@After
	public void tearDown() throws Exception {
		produs = null;
	}

	@Test
	public void testRightAdaugaSaptamana() throws ExceptieProduseNevanduteSapt, ExceptieProduseVandute, ExceptieIndex {

		ArrayList<Integer> nrProduseDeVandut = new ArrayList<>(
				Arrays.asList(InterfataProdus.MAX_PRODUSE_VANDUTE + 1, InterfataProdus.MIN_PRODUSE_VANDUTE + 1));
		ArrayList<Integer> nrProduseVandute = new ArrayList<>(Arrays.asList(InterfataProdus.MAX_PRODUSE_VANDUTE + 1));

		produs.setVanzari(nrProduseVandute);
		produs.adaugaSaptamana(InterfataProdus.MIN_PRODUSE_VANDUTE + 1);

		ArrayList<Integer> calculeazaSaptamani = new ArrayList<>();
		for (int i = 0; i < produs.getNrSaptamani(); i++) {
			calculeazaSaptamani.add(produs.getNrProduseVandute(i));

		}
		assertEquals(nrProduseDeVandut, calculeazaSaptamani);

	}

	@Test
	public void testGetNrProduseRight() throws ExceptieProduseNevanduteSapt, ExceptieIndex {
		int sapt = 0;

		ArrayList<Integer> produseVandSapt = new ArrayList<>(Arrays.asList(InterfataProdus.MIN_PRODUSE_VANDUTE + 1));
		produs.setVanzari(produseVandSapt);

		int produseDeVandut = InterfataProdus.MIN_PRODUSE_VANDUTE + 1;
		int calculeazaProduseVandute = produs.getNrProduseVandute(sapt);

		assertEquals(produseDeVandut, calculeazaProduseVandute);
	}

	@Test
	public void testGetNrSaptPesteMedieRight() throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE + 1;
		ArrayList<Integer> produse = new ArrayList<>(Arrays.asList(InterfataProdus.MIN_PRODUSE_VANDUTE + 2));
		produs.setVanzari(produse);
		int saptPesteLimita = 1;
		// int saptPesteLimita =2 ;

		assertEquals("sapt peste limita", saptPesteLimita, produs.getNrSaptamaniPesteMedie(limita));

	}

	@Test(expected = ExceptieProduseVandute.class)
	public void testRangeNegativAdaugaSaptamana() throws ExceptieProduseVandute {
		int produse = -4;
		produs.adaugaSaptamana(produse);

	}

	@Test(expected = ExceptieIndex.class)
	public void testRangeGetNrProduseVanduteNIndex() throws ExceptieProduseNevanduteSapt, ExceptieIndex {
		ArrayList<Integer> produse = new ArrayList<>(Arrays.asList(InterfataProdus.MIN_PRODUSE_VANDUTE + 1));
		produs.setVanzari(produse);

		int sapt = produse.size() + 1;
		produs.getNrProduseVandute(sapt);

	}

	@Test(expected = ExceptieLimitaMinimaNegativa.class)
	public void testGetNrSaptPesteMedieRange() throws ExceptieLimitaMinimaNegativa {
		int limita = -1;
		produs.getNrSaptamaniPesteMedie(limita);
	}

	@Test
	public void testAdaugaSaptLimitaExtremaMinima() throws ExceptieIndex, ExceptieProduseVandute {
		produs.adaugaSaptamana(InterfataProdus.MIN_PRODUSE_VANDUTE);
		int produseDeVandut = InterfataProdus.MIN_PRODUSE_VANDUTE;
		int produseVnadute = produs.getNrProduseVandute(produs.getProduseVanduteSapt().size() - 1);
		assertEquals("limita minima", produseDeVandut, produseVnadute);

	}

	@Category(TesteImportante.class)
	@Test
	public void testAdaugaSaptLimitaExtremaMaxima() throws ExceptieIndex, ExceptieProduseVandute {
		produs.adaugaSaptamana(InterfataProdus.MAX_PRODUSE_VANDUTE);
		int produseDeVandut = InterfataProdus.MAX_PRODUSE_VANDUTE;
		int produseVnadute = produs.getNrProduseVandute(produs.getProduseVanduteSapt().size() - 1);
		assertEquals("limita maxima ", produseDeVandut, produseVnadute);

	}

	@Test
	public void testNrProduseVanduteLimitaExtremaMinima() throws ExceptieIndex {
		int sapt = InterfataProdus.MIN_SAPTAMANI;
		int produseDeVandut = InterfataProdus.MIN_PRODUSE_VANDUTE + 1;
		int produseVnadute = produs.getNrProduseVandute(sapt);
		assertEquals("limita minima produse vandute", produseDeVandut, produseVnadute);

	}

	@Test
	public void testNrProduseVanduteLimitaExtremaMaxima() throws ExceptieIndex {
		int sapt = produs.getProduseVanduteSapt().size() - 1;
		int produseDeVandut = InterfataProdus.MIN_PRODUSE_VANDUTE + 1;
		int produseVnadute = produs.getNrProduseVandute(sapt);
		assertEquals("limita maxima produse vandute", produseDeVandut, produseVnadute);

	}

	@Test
	public void testgetSaptPesteMedieLimitaExtremaMinima()
			throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		ArrayList<Integer> vanzariProduse = new ArrayList<>(Arrays.asList(InterfataProdus.MIN_PRODUSE_VANDUTE));
		produs.setVanzari(vanzariProduse);
		int saptPeste = 1;
		assertEquals("test extrema stanga", saptPeste, produs.getNrSaptamaniPesteMedie(limita));
	}

	@Test
	public void testgetSaptPesteMedieLimitaExtremaMaxima()
			throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		ArrayList<Integer> vanzariProduse = new ArrayList<>(Arrays.asList(InterfataProdus.MIN_PRODUSE_VANDUTE));
		produs.setVanzari(vanzariProduse);
		int saptPeste = 1;
		assertEquals("test extrema dreapta", saptPeste, produs.getNrSaptamaniPesteMedie(limita));
	}

	@Test
	public void testgetNrSaptPesteMedieCardinalitateUnu()
			throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		int produseVandute = InterfataProdus.MIN_PRODUSE_VANDUTE;
		ArrayList<Integer> produseSaptamanale = new ArrayList<>();
		produseSaptamanale.add(produseVandute);
		produs.setVanzari(produseSaptamanale);

		int pesteLimita = 1;
		int saptPesteLimita = produs.getNrSaptamaniPesteMedie(limita);

		assertEquals(pesteLimita, saptPesteLimita);
	}

	@Test
	public void testgetNrSaptPesteMedieCardinalitateZero()
			throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {

		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		ArrayList<Integer> produseSaptamanale = new ArrayList<>();
		produs.setVanzari(produseSaptamanale);

		int pesteLimita = 0;
		int saptPesteLimita = produs.getNrSaptamaniPesteMedie(limita);

		assertEquals(pesteLimita, saptPesteLimita);
	}

	@Test
	public void testGetNrSaptPesteMedieCrescator() throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		ArrayList<Integer> produseSaptamanale = new ArrayList<>();
		for (int i = 0; i < nrProduseVandute; i++) {
			produseSaptamanale.add(InterfataProdus.MIN_PRODUSE_VANDUTE + i);
		}
		produs.setVanzari(produseSaptamanale);

		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		int saptPesteLimita = nrProduseVandute;
		int sapt = produs.getNrSaptamaniPesteMedie(limita);
		assertEquals(saptPesteLimita, sapt);

	}

	@Test
	public void testGetNrSaptPesteMedieDesrescator() throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {
		ArrayList<Integer> produseSaptamanale = new ArrayList<>();
		for (int i = 0; i < nrProduseVandute; i++) {
			produseSaptamanale.add(InterfataProdus.MIN_PRODUSE_VANDUTE - i);
		}
		produs.setVanzari(produseSaptamanale);

		int limita = InterfataProdus.MIN_PRODUSE_VANDUTE;
		int saptPesteLimita = nrProduseVandute;
		int sapt = produs.getNrSaptamaniPesteMedie(limita);
		assertEquals(saptPesteLimita, sapt);

	}

	@Category(TesteImportante.class)
	@Test(timeout = 3000)
	public void testePerformantaGetNrSaptPesteMedie()
			throws ExceptieProduseNevanduteSapt, ExceptieLimitaMinimaNegativa {

		int nrSapt = InterfataProdus.MAX_SAPTAMANI_PERFORMANTA;
		int numarSapt = produs.getNrSaptamaniPesteMedie(InterfataProdus.MIN_PRODUSE_VANDUTE);

		assertEquals("performanta", nrSapt, numarSapt);
	}

	@Test(expected = ExceptieIndex.class)
	public void testGetNrProduseVanduteError() throws ExceptieProduseVandute, ExceptieIndex {

		int produseVandute = InterfataProdus.MIN_PRODUSE_VANDUTE - 1;
		produs.getNrProduseVandute(produseVandute);
	}

	@Test(expected = ExceptieIndex.class)
	public void testGetNrProduseVanduteMaxError() throws ExceptieProduseVandute, ExceptieIndex{
		
		int produseVandute=InterfataProdus.MAX_PRODUSE_VANDUTE +1;
		produs.getNrProduseVandute(produseVandute);
	
	}
}
