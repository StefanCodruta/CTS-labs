package Exceptii;

public class ExceptieLimitaMinimaNegativa extends Exception{

}
