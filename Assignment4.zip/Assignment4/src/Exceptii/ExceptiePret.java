package Exceptii;

public class ExceptiePret extends Exception {

}
