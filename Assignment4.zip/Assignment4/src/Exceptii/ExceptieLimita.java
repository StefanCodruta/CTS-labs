package Exceptii;

public class ExceptieLimita extends Exception{

}
