package Exceptii;

public class ExceptieProduseVandute extends Exception{

}
