package Exceptii;

public class ExceptieNume extends Exception{

}
