package Exceptii;

public class ExceptieProduseNevanduteSapt extends Exception{

}
