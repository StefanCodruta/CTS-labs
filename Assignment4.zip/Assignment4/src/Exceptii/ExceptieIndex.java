package Exceptii;


public class ExceptieIndex extends Exception{

}
