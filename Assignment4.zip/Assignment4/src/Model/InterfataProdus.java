package Model;


public interface InterfataProdus {

	public static final int MIN_LUNGIME_NUME = 3;
	public static final int MAX_LUNGIME_NUME = 200;
	public static final float MIN_PRET=0.01f;
	public static final float MAX_PRET=100000f;
	public static final int MIN_PRODUSE_VANDUTE=0;
	public static final int MAX_PRODUSE_VANDUTE=1000;
	public static final int MIN_SAPTAMANI = 0;
	public static final int MAX_SAPTAMANI = 52;
	public static final int NR_SAPT = 3;
	
	public static final int MAX_SAPTAMANI_PERFORMANTA=1000;
	
}
