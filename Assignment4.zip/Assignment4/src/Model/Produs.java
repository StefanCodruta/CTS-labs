package Model;

import java.util.ArrayList;

import Exceptii.ExceptieIndex;
import Exceptii.ExceptieLimita;
import Exceptii.ExceptieLimitaMinimaNegativa;
import Exceptii.ExceptieNume;
import Exceptii.ExceptiePret;
import Exceptii.ExceptieProduseNevanduteSapt;
import Exceptii.ExceptieProduseVandute;

/*
 * 
 * DISCLAIMER
 * 
 * Cele mai multe dintre metodele date au bug-uri si greseli de implementare
 * 
 * 
 * SPECS
 * 
 * nume - intre 5 si 200 caractere alfa-numerice (fara caractere speciale)
 * pret - intre [0.01, 100000)
 * valori in produseVanduteSaptamanal - intre [0, 1000]
 * 
 * 
 */

public class Produs {

	private String nume;
	private float pret;
	private ArrayList<Integer> produseVanduteSaptamanal;
	// numar de produse vandute in fiecare saptamana

	public Produs(String nume, float pret) throws ExceptieNume, ExceptiePret {
		if (nume.length() < InterfataProdus.MIN_LUNGIME_NUME || nume.length() > InterfataProdus.MAX_LUNGIME_NUME) {
			throw new ExceptieNume();
		}
		this.nume = nume;
		if (pret < InterfataProdus.MIN_PRET || pret > InterfataProdus.MAX_PRET) {
			throw new ExceptiePret();
		}
		this.pret = pret;
		this.produseVanduteSaptamanal = new ArrayList<>();

	}

	public Produs(String nume, float pret, ArrayList<Integer> produseVanduteSaptamanal)
			throws ExceptieNume, ExceptiePret, ExceptieProduseNevanduteSapt
	{
		if (nume.length() < InterfataProdus.MIN_LUNGIME_NUME || nume.length() > InterfataProdus.MAX_LUNGIME_NUME) {
			throw new ExceptieNume();
		}
		this.nume = nume;
		if (pret < InterfataProdus.MIN_PRET || pret > InterfataProdus.MAX_PRET) {
			throw new ExceptiePret();
		}
		this.pret = pret;
		if (produseVanduteSaptamanal.size() < InterfataProdus.MIN_PRODUSE_VANDUTE || produseVanduteSaptamanal.size() >InterfataProdus.MAX_PRODUSE_VANDUTE) {
			throw new ExceptieProduseNevanduteSapt();
		}
		this.produseVanduteSaptamanal = new ArrayList<Integer>();
		for (Integer n : produseVanduteSaptamanal)
			this.produseVanduteSaptamanal.add(n);
	}

	public void setVanzari(ArrayList<Integer> produseVanduteSaptamanal) throws ExceptieProduseNevanduteSapt {
		if (produseVanduteSaptamanal == null) {
			throw new ExceptieProduseNevanduteSapt();
		}
		this.produseVanduteSaptamanal = new ArrayList<Integer>();
		for (int nrProduseVandute : produseVanduteSaptamanal) {
			this.produseVanduteSaptamanal.add(nrProduseVandute);
		}
	}

	public String getName() {
		return this.nume;
	}

	public float getPret() {
		return this.pret;
	}

	public ArrayList<Integer> getProduseVanduteSapt(){
		return produseVanduteSaptamanal;
	}
	public void adaugaSaptamana(int produseVandute) throws ExceptieProduseVandute {

		if (produseVandute < 0) {
			throw new ExceptieProduseVandute();
		}
		if (produseVandute < InterfataProdus.MIN_PRODUSE_VANDUTE
				|| produseVandute > InterfataProdus.MAX_PRODUSE_VANDUTE) {
			throw new ExceptieProduseVandute();
		}
		produseVanduteSaptamanal.add(produseVandute);
	}

	public int getNrProduseVandute(int i) throws ExceptieIndex {

		if (i > produseVanduteSaptamanal.size()) {
			throw new ExceptieIndex();
		}
		if (i < InterfataProdus.MIN_PRODUSE_VANDUTE || i > InterfataProdus.MAX_PRODUSE_VANDUTE) {
			throw new ExceptieIndex();
		}
		return this.produseVanduteSaptamanal.get(i);
	}

	public int getNrSaptamani() {
		return this.produseVanduteSaptamanal.size();
	}

	/*
	 * 
	 * 
	 * determina numarul de saptamani in care au fost vandute un numar de produse
	 * peste limita data
	 * 
	 */
	public int getNrSaptamaniPesteMedie(int minLimit) throws ExceptieLimitaMinimaNegativa {
		if (minLimit < 0) {
			throw new ExceptieLimitaMinimaNegativa();
		}

		int nrSaptamani = 0;
		for (int n : produseVanduteSaptamanal)
			if (n >= minLimit) {
				nrSaptamani++;
			}

		return nrSaptamani;
	}

	/*
	 * 
	 * 
	 * determina procentul saptamanilor (din total saptamani) care au avut vanzari
	 * sub limita data
	 * 
	 */
	public int getProcentSaptamaniSlabe(int minLimit) throws ExceptieLimitaMinimaNegativa, ExceptieLimita {
		if (minLimit < 0) {
			throw new ExceptieLimitaMinimaNegativa();
		}
		if (minLimit > InterfataProdus.MAX_PRODUSE_VANDUTE) {
			throw new ExceptieLimita();
		}

		float m = 0;
		for (Integer n : produseVanduteSaptamanal)
			if (n < minLimit)
				m++;

		return (int) (100 * m / this.produseVanduteSaptamanal.size());
	}

	/*
	 * 
	 * 
	 * 
	 * determina indexul saptamanilor cu vanzari maxime (mai multe saptamani pot
	 * avea vanzari la nivel maxim)
	 * 
	 * 
	 */

	public ArrayList<Integer> getIndexSaptamaniCuVanzariMaxime() {
		ArrayList<Integer> saptamaniMax = new ArrayList<>();
		int max = this.produseVanduteSaptamanal.get(0);

		for (int i = 0; i < this.produseVanduteSaptamanal.size(); i++)
			if (this.produseVanduteSaptamanal.get(i) >= max)
				saptamaniMax.add(i);

		return saptamaniMax;
	}

	@Override
	public String toString() {
		String output = this.nume + " vanzari saptamanale: ";
		for (Integer n : produseVanduteSaptamanal)
			output += n + " ";
		return output;
	}
}
