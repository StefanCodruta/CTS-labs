package CreditBancar;

public enum TipDeCreditBancar {

	STANDARD, BUGET, PREMIUM, SUPER_PREMIUM;

	private final int tipCont = 0;

	public int getTip() {
		return this.tipCont;
	}
}
