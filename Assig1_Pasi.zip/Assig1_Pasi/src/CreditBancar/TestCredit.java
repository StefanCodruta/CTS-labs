package CreditBancar;
import Exceptii.ExceptieValoare;

public class TestCredit {
	public static void main(String[] args) {
		try {
			
			CreditBancar creditBancar1 = new CreditBancar(1000, 5, 234, TipDeCreditBancar.PREMIUM);
			//CreditBancar creditBancar2= new CreditBancar(-2, 12, 130, TipDeCreditBancar.SUPER_PREMIUM);
			
			CreditBancar[] crediteBancare = {creditBancar1, creditBancar1};
			
			creditBancar1.getRataImprumut();
			
			System.out.println("comision total = " + CreditBancar.CalculeazaComision(crediteBancare));

		} catch (ExceptieValoare e) {
			e.printStackTrace();
		}

	}

}
