package CreditBancar;
import Exceptii.ExceptieValoare;
import InterfeteCont.DobandaPrincipala;
import InterfeteCont.InterfataDobanda;
import InterfeteCont.InterfataVerficareValoare;
import InterfeteCont.VerificaValori;

public class CreditBancar {

	private double valoareImprumutBancar;
	private double rataImprumut;
	private int zileImprumutActive;
	static TipDeCreditBancar tip_Credit;

	InterfataVerficareValoare verificaValoare = new VerificaValori();

	public CreditBancar(double valoareImprumutBancar, double rataImprumut, int zileImprumutActive,
			TipDeCreditBancar tip_Credit) throws ExceptieValoare {

		verificaValoare.valideazaValoreImprumut(valoareImprumutBancar);
		this.valoareImprumutBancar = valoareImprumutBancar;

		verificaValoare.valideazaRataImprumut(rataImprumut);
		this.rataImprumut = rataImprumut;
		this.zileImprumutActive = zileImprumutActive;
		this.tip_Credit = tip_Credit;
	}

	public double getValoare_imprumutbancar() {
		System.out.println("Valoarea imprumutului este " + this.valoareImprumutBancar);
		return valoareImprumutBancar;
	}

	public void setValoare_imprumutbancar(double valoareImprumutBancar) throws ExceptieValoare {

		verificaValoare.valideazaValoreImprumut(valoareImprumutBancar);
		this.valoareImprumutBancar = valoareImprumutBancar;

	}

	public double getRataImprumut() {
		System.out.println("Rata este " + this.rataImprumut);
		return rataImprumut;
	}

	public int getZileImprumutActive() {
		return zileImprumutActive;
	}

	public TipDeCreditBancar getTip_credit() {
		return tip_Credit;
	}

	@Override
	public String toString() {
		return "Imprumut bancar are valoarea : " + valoareImprumutBancar + ", rata imprumutului este : " + rataImprumut
				+ ", imprumut valid pentru : " + zileImprumutActive
				+ " zile, iar tipul de credit solicitat al beneficiarului este : " + tip_Credit;
	}

	public double getRataLunara() {
		return valoareImprumutBancar * rataImprumut;
	}

	public static double CalculeazaComision(CreditBancar[] credite) {
		InterfataDobanda dobandaPrincipala = new DobandaPrincipala();
		double comisionTotal = 0.0;
		double dobanda = 0.0;
		CreditBancar credit;
		for (int i = 0; i < credite.length; i++) {
			credit = credite[i];
			if (credit.tip_Credit == TipDeCreditBancar.PREMIUM || credit.tip_Credit == TipDeCreditBancar.SUPER_PREMIUM)
				dobanda = dobandaPrincipala.calculDobandaPrincipala(credit.valoareImprumutBancar, credit.rataImprumut,
						credit.zileImprumutActive);
			comisionTotal += dobanda;
		}
		return comisionTotal;

	}

}
