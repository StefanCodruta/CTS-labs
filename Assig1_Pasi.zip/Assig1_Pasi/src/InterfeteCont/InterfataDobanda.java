package InterfeteCont;

public interface InterfataDobanda {

	public double calculDobandaPrincipala(double valoareImprumutBancar, double rataImprumut, int zileImprumutActive);

}
