package InterfeteCont;

import Exceptii.ExceptieValoare;

public class VerificaValori implements InterfataVerficareValoare{

	@Override
	public void valideazaValoreImprumut(double valoareImprumutBancar) throws ExceptieValoare {
		
		if(valoareImprumutBancar < 0) {
			throw new ExceptieValoare();
		}
	}
	

	@Override
	public void valideazaRataImprumut(double rataImprumut) throws ExceptieValoare {
		
		if(rataImprumut < 0) {
			throw new ExceptieValoare();
		}
	}

}
