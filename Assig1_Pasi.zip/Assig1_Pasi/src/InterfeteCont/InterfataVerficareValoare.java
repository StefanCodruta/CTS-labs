package InterfeteCont;

import Exceptii.ExceptieValoare;

public interface InterfataVerficareValoare {

	public void valideazaValoreImprumut(double valoareImprumutBancar) throws ExceptieValoare;

	public void valideazaRataImprumut(double rataImprumut) throws ExceptieValoare;
}
