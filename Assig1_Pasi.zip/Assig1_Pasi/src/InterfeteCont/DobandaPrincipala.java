package InterfeteCont;

public class DobandaPrincipala implements InterfataDobanda {

	public static final int ZILE_AN = 365;
	public static final float TAXA_AGENT = .0125f;
	
	@Override
	public double calculDobandaPrincipala(double valoareImprumutBancar, double rataImprumut, int zileImprumutActive) {
		return TAXA_AGENT * valoareImprumutBancar * Math.pow(rataImprumut, (zileImprumutActive / ZILE_AN))
				- valoareImprumutBancar;
	}

}
