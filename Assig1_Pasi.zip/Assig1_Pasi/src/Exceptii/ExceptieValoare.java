package Exceptii;

public class ExceptieValoare extends Exception {

	public ExceptieValoare() {
		System.out.println("valoarea este invalida");

	}
	
}