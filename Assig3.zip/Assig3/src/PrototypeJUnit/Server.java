package PrototypeJUnit;

import java.util.Hashtable;

public class Server implements InterfataServer {

	String ip;
	int port;

	
	private static Hashtable<Integer, Server> conexiuni = new Hashtable<>();

	public void setIp(String ip) {
		if (this.ip.length() > 0 || this.ip.length() < 8) {

		}
		this.ip = ip;
	}

	private Server() {

	}

	@Override
	public String getAdresaIp() {
		return ip;
	}

	public Server(String ip, int port) {
		super();
		this.ip = ip;
		this.port = port;

	}

	@Override
	public int getPort() {
		return port;
	}

	@Override
	public int getNrMaximConexiuni() {
		return 0;

	}

	@Override
	public boolean conectare() {

		return true;
	}

	@Override
	public boolean deconectare() {

		return true;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {

		Server copieServer = new Server();
		copieServer.ip = this.ip;
		copieServer.port = this.port;
		copieServer.conexiuni = (Hashtable<Integer, Server>) this.conexiuni.clone();

		return copieServer;

	}

}
