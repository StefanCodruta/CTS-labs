package PrototypeJUnit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class Testare {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testareClone() throws CloneNotSupportedException {
		Server server1=new Server("ip1",8080);
		server1.setIp("ip1");
		
		Server server2=(Server)server1.clone();
		server2.setIp("ip2");
		
		assertEquals("ip1",server1.getAdresaIp());
		assertEquals("ip2",server2.getAdresaIp());
	}
}
