package ProxyJUNIT;


public class Server implements  ProxyJUNIT.InterfataServer {

	String ip;
	int port;

	public Server(String ip, int port) {
		super();
		this.ip = ip;
		this.port = port;
	}


	@Override
	public String getAdresaIp() {
		return ip;
	}


	@Override
	public int getPort() {
		return port;
	}

	
	@Override
	public int getNrMaximConexiuni() {
	
		return 1;
      
	}

	@Override
	public boolean conectare(String utilizator,String parola) {
		if(utilizator.equals("utlizator223@gmail.com")) {
			return true;
		}
		else
			return false;
	}

	@Override
	public boolean deconectare() {
	 
	 return true;
	}




	
	
	
	
	

}
