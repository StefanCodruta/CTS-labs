package ProxyJUNIT;


import java.util.HashMap;
import java.util.Map;

import PrototypeJUnit.InterfataServer;

public class ProxyServer implements ProxyJUNIT.InterfataServer{

	ProxyJUNIT.InterfataServer interfata;
	Map<String, Integer> utilizatori= new HashMap<>();
	
	public ProxyServer(ProxyJUNIT.InterfataServer interfataS) {
		super();
		this.interfata = interfataS;
	}

	@Override
	public String getAdresaIp() {
		return interfata.getAdresaIp();
	}

	@Override
	public int getPort() {
		return interfata.getPort();
	}

	@Override
	public int getNrMaximConexiuni() {
		
		return interfata.getNrMaximConexiuni();
	}


	@Override
	public boolean deconectare() {
		
		return interfata.deconectare();
	}

	@Override
	public boolean conectare(String utilizator, String parola) {
		if (interfata.conectare(utilizator,parola)) {
			utilizatori.put(utilizator, 0);
			return true;
		
	}else {
		return false;
	}
	}

}
