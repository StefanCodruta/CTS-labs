package ProxyJUNIT;

public interface InterfataServer {

		public String getAdresaIp();
	    public int getPort();
	    public int getNrMaximConexiuni();

	    public boolean conectare(String utilizator,String parola);
	    public boolean deconectare();
}
