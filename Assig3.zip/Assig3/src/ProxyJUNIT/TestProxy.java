package ProxyJUNIT;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestProxy {

	ProxyJUNIT.InterfataServer interfata;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Ignore
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	@Test
	public void testProxy1() {
		interfata = new Server("127.0.0.1", 8080);
		InterfataServer proxy = new ProxyServer(interfata);
		String utilizator = "utilizator1234@gmail.com";
		boolean conexiuneServer  = proxy.conectare(utilizator, "1123445");
		assertEquals("Conexiune realizata cu succes !",false, conexiuneServer);
		
	}
	
	@Test
	public void testProxy2() {
		
		interfata =  new Server("127.0.0.1",8080);
		InterfataServer Proxy = new ProxyServer(interfata);
		String utilizator2 = "gigel123@gmail.com";
		boolean conexiuneServer2 = Proxy.conectare(utilizator2, "123456");
		assertNotEquals("numele de utilziator introdus este gresit", false, conexiuneServer2);
		
	}

}
