package SingletonJUnit;

import java.util.Hashtable;

public class Server implements InterfataServer {

	 String ip;
	 int port;

	// instanta
	private static Server conexiune = null;
	private static Hashtable<Integer, Server> conexiuni = new Hashtable<>();

	private Server() {

	}

	private Server(String ip, int port) {
		super();
		this.ip = ip;
		this.port = port;

	}
	

	public void setIp(String ip) {
		this.ip = ip;
	}

	@Override
	public String getAdresaIp() {
		return ip;
	}

	@Override
	public int getPort() {
		return port;
	}

	// obtine instanta
	public static synchronized Server getConexiune() {

		if (conexiune == null) {
			conexiune = new Server("10.01.1.02", 8080);

		}
		return conexiune;
	}

	@Override
	public int getNrMaximConexiuni() {
		int nrMaxim = 1;

		return nrMaxim;

	}

	@Override
	public boolean conectare() {
		if (conexiune == null) {
			conexiune = new Server("10.02.0.2", 8080);
		}
		return true;
	}

	@Override
	public boolean deconectare() {
		if (conexiune == null) {
			System.out.println("conexiunea nu exista");
		}
		return true;
	}

}
