package SingletonJUnit;

public class ExceptieSingleton extends Exception{

}
